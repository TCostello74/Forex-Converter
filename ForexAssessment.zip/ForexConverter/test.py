import unittest
from app import app


class TestApp(unittest.TestCase):

    def setUp(self):
        self.app = app.test_client()

    def test_home_page(self):
        response = self.app.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Welcome to Currency Converter", response.data)

    def test_show_form(self):
        response = self.app.get("/form")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Currency Converter", response.data)

    def test_get_data(self):
        response = self.app.get("/api/data?convert_from=USD&convert_to=EUR&amount=1")
        self.assertEqual(response.status_code, 200)
         
    def test_usd_to_usd(self):
        response = self.app.get('/api/data?convert_from=USD&convert_to=USD&amount=1')
        self.assertIn(b'The converted amount is: $1', response.data)
  

if __name__ == '__main__':
    unittest.main()
