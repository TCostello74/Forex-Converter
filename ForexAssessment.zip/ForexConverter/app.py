from flask import Flask, render_template, request
import requests, re
from flask_debugtoolbar import DebugToolbarExtension
from forex_python.converter import CurrencyCodes

app = Flask(__name__)
app.config['SECRET_KEY'] = "Tyler"
app.config['DEBUG_TB_INTERCEPT_REDIRECTS'] = False

debug = DebugToolbarExtension(app)

@app.route("/")
def home_page():
    
    return render_template("base.html")

@app.route("/form")
def show_form():

    return render_template("form.html")

@app.route('/api/data')
def get_data():
    # convert_from = request.args.get("from")
    # convert_to = request.args.get("to")
    # convert_from = request.args.get("base")
    # convert_to = request.args.get("symbols")
    convert_from = request.args.get("convert_from")
    convert_to = request.args.get("convert_to")
    amount = request.args.get("amount")

    # url = f'https://api.exchangerate.host/convert?from={convert_from}&to={convert_to}&amount={amount}'
    url = f'https://api.exchangerate.host/latest?base={convert_from}&symbols={convert_to}&amount={amount}'
    response = requests.get(url)
    data = response.json()
    
    currency_codes = CurrencyCodes()


    
    rates = data.get("rates")
    pattern = re.compile(r"^[A-Z]{3}$")
    
    if response.status_code == 200 and convert_to in rates and pattern.match(convert_from):
        for key, value in rates.items():
            if pattern.match(key):
                currency_symbol = currency_codes.get_symbol(convert_to)
                currency_value = round(value, 2)

    # print(converted_amount)
    # print("Hello World")
    # print(currency_symbol)
    # print(currency_value)
    # print(data)
    
        return render_template("results.html", symbol=currency_symbol, value=currency_value)
    else: 
        error_msg = f"Error: cannot convert {amount} {convert_from} to {convert_to}"
        return render_template("form.html", error=error_msg)
    # return render_template("result.html", converted_amount = converted_amount, convert_from = convert_from, convert_to = convert_to, amount = amount)


